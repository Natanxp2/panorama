"use strict";
// This is mirrored from C++ code! Do not change whimsically!
const RunEntType = {
    PLAYER: 0,
    GHOST: 1,
    REPLAY: 2,
    ONLINE: 3
};
