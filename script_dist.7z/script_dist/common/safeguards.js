"use strict";
const RunSafeguardType = {
    PRACTICEMODE: 0,
    RESTART: 1,
    RESTART_STAGE: 2,
    SAVELOC_TELE: 3,
    CHAT_OPEN: 4,
    MAP_CHANGE: 5,
    QUIT_TO_MENU: 6,
    QUIT_GAME: 7,
    COUNT: 8,
    INVALID: -1
};
