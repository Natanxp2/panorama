"use strict";
const GameUIState = {
    INVALID: 0,
    LOADINGSCREEN: 1,
    INGAME: 2,
    MAINMENU: 3,
    PAUSEMENU: 4,
    INTROMOVIE: 5
};
